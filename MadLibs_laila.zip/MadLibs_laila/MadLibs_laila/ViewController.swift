//
//  ViewController.swift
//  MadLibs_laila
//
//  Created by administrator on 13/12/2021.
//

import UIKit

class ViewController: UIViewController {
    
    var output:String?
    
    @IBOutlet var ResultLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }


    @IBAction func unwind( _ seg: UIStoryboardSegue) {
        
        guard let result = output else {return}
        ResultLabel.text = result
    }
}
