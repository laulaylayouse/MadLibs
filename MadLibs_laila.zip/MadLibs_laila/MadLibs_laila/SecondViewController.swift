//
//  SecondViewController.swift
//  MadLibs_laila
//
//  Created by administrator on 14/12/2021.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet var Adjective: UITextField!
    @IBOutlet var Verb1: UITextField!
    @IBOutlet var Verb2: UITextField!
    @IBOutlet var Noun: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
       let destination = segue.destination as! ViewController
        
        destination.output = "We are having a perfectly \(Adjective.text ?? "") right now. Later we will \(Verb1.text ?? "") and \(Verb2.text ?? "") in the \(Noun.text ?? "")"
        print("destination")
       
    }
}
